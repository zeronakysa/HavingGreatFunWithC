#include "functions.h"

int main() {
    createDatabase();
    return 0;
}