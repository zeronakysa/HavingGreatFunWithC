//
// Created by Zero on 05/02/2018.
//

#ifndef BDDSERVER_FUNCTIONS_H
#define BDDSERVER_FUNCTIONS_H

#include <stdio.h>
#include <stdlib.h>
#include <winsock.h>
#include <MYSQL/mysql.h>

void createDatabase();

#endif //BDDSERVER_FUNCTIONS_H
